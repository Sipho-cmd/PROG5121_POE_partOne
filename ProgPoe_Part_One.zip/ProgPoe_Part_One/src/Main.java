void main() {
    Registration registration = new Registration();
    registration.Registration();

    String[] data = registration.getUserDetails();

    //Extracting the username from the array (position 0)
    String userName = data[0];

    //Extracting the password from the array (position 1)
    String passWord = data[1];

    //Extracting the password from the array (position 2)
    String phoneNumber = data[2];

    //allows us to use the login method
    Login login = new Login();

    //This methid will deploy the users data data
    login.displayUserDetails(userName, passWord, phoneNumber);
}