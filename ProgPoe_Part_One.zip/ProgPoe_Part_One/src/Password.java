public class Password {

    public void WelcomeMessage(){
        System.out.println("Welcome to the 2nd");
    }
}
