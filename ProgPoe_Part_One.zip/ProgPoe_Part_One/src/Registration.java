import javax.swing.*;
import java.util.Scanner;

//Declaration
public class Registration {
    String userName;
    String passWord;
    int minLength = 8; //Minimum password length
    String phoneNumber;

    public void Registration() {
        Scanner input = new Scanner(System.in);

        //User name validation loop until a valid username is entered
        while (true) {
            System.out.print("Enter your user Name ");
            userName = input.nextLine();

            // check if the username contains "_" and is <= 5 characters
            if (userName.length() <= 5 && userName.contains("_")) {
                System.out.println("User name has been succesfully captured");
                break; // Exit loop if username fits the requirements

            } else {
                System.out.println("User name must contain [ _ ] and must not be more than 5 characters long");
            }
        }

        //password validation loop until a valid password is entered
        while (true) {
            System.out.print("Enter your password ");
            passWord = input.nextLine();

            // Call Validation method
            if (isValidPassword(passWord, minLength)) {
                System.out.println("Password is correct");
                break;

            } else {
                System.out.println("Password must be at lease 8 characters long, contain a capital letter and a special " +
                        "character");
            }
        }

        //phone number validation enters a loop until a valid phone number coming with the user country code
        while (true) {
            System.out.print("Enter your South African phone ");
            phoneNumber = input.nextLine();

            if (isValidphoneNumber(phoneNumber)) {
                System.out.println("Cell phone number successfully added");
                break;

            } else {
                System.out.println("Cell phone number incorrectly formatted or does not contain international code");
            }
        }

        //close scanner
        input.close();
    }

    //method to validate South African phone number
    public static boolean isValidphoneNumber(String phoneNumber) {

        //must start with +27 and be exactly 12 character long
        if (phoneNumber.startsWith("+27") && phoneNumber.length() == 12) {
            return true;
        }
            return false;
    }

    //method to validate password rules
    public static boolean isValidPassword(String password, int minLength) {

        //check minimum length
        if (password.length() < 8) {
            return false;
        }
            //flags to check conditions
            boolean hadUppercase = false;
            boolean hasSpecial = false;

            //loop through each character in password
            for (int i = 0; i < password.length(); i++){
            char ch = password.charAt(i);

            //check for uppercase letter
            if (Character.isUpperCase(ch)) {
                hadUppercase = true;
            }

            //check for special character
            if (!Character.isLetterOrDigit(ch)) {
                hasSpecial = true;
            }
        }

            //password is valid only if both conditions are true
            return hadUppercase && hasSpecial;

    }

    //method to return all user details as an array
    public String[] getUserDetails() {
        return  new String[]{userName, passWord, phoneNumber};
    }
}
