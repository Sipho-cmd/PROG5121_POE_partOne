public class Login {

    public void displayUserDetails(String userName, String passWord, String phoneNumber) {

        System.out.println("Welcome, " + userName);             //Display welcome message using the username
        System.out.println("--------------------");             //Print a seperator line for formatting
        System.out.println("Username : " + userName);           //Display the username
        System.out.println("Password : " + passWord);           //Display the password
        System.out.println("Phone Number : " + phoneNumber);    // display the phone number
        System.out.println("--------------------");             //closing the seperator

    }
}